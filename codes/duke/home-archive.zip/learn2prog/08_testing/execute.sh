#!/bin/bash



./isPrime-broken3 $1


echo Correct Answer
./isPrime-correct $1
